function sure()
{
    confirm("Are you sure ?");
}